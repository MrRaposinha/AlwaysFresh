# Always Fresh
A mod for ULTRAKILL that enhances the player's experience by eliminating the penalties imposed by the style and freshness systems. With **AlwaysFresh**, you can focus entirely on stylish combat without worrying about freshness decay or repetitive actions reducing your style score.

## Features
- Keeps all weapons' freshness at the "Fresh" state, ensuring a consistent style multiplier.
- Removes penalties from the style meter for actions deemed "repetitive."
- Fixes the style decay mechanism to prevent unnecessary point loss.

## Technical Details
- **Freshness System:** The mod intercepts the `DecayFreshness` and `UpdateFreshness` methods, ensuring weapon freshness remains at the maximum.
- **Style Meter:** It modifies style point calculations in `AddPoints`, bypassing penalties for repetitive or non-varied actions.

## Changelog
### 1.0.0
- Initial release.
  - Added functionality to lock weapon freshness at its maximum value.
  - Removed penalties for repetitive actions in style scoring.
